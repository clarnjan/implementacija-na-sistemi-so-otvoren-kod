<?php
$DB_HOST = 'praktikum.finki.ukim.mk';
$DB_NAME = 'isok171146'; //TODO
$DB_USER = '171146'; //TODO
$DB_PASS = '171146Lozinka'; //TODO
$DB_TYPE = 'mysql';
?>